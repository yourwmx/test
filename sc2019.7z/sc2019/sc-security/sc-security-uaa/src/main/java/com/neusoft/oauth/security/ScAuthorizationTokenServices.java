package com.neusoft.oauth.security;

import org.springframework.security.oauth2.provider.token.DefaultTokenServices;

/**
 * <p>token服务类</p>
 * <p>创建日期：2018-01-10</p>
 *
 * @author 杨洲 yangzhou@neusoft.com
 */
public class ScAuthorizationTokenServices extends DefaultTokenServices {

}
