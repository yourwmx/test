package com.neusoft.job.util;

import org.quartz.JobExecutionContext;

public class ScRemoteHttpJobBeanUtils {

    public static void excuteJob(JobExecutionContext context){

    }
}
