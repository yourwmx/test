package com.neusoft.core.validate;

public interface UpdateGroup {
}
