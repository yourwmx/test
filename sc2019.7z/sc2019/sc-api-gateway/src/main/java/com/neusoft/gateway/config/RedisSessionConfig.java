package com.neusoft.gateway.config;

/**
 * <p>spring session设置</p>
 * <p>创建日期：2018-01-01</p>
 * 
 * @author 杨洲 yangzhou@neusoft.com
 */
//@Configuration
//@EnableRedisHttpSession(maxInactiveIntervalInSeconds = 600)
public class RedisSessionConfig {

}
