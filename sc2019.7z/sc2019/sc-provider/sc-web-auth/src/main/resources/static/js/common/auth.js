function set(key,data){
    sessionStorage().setItem(key, data)
}