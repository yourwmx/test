package com.neusoft.webauth.user.entity;

public interface AddUserGroup {
}
