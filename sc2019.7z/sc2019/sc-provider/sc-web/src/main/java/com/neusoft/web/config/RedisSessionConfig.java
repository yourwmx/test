package com.neusoft.web.config;

import org.springframework.context.annotation.Configuration;
//import org.springframework.session.data.redis.config.annotation.web.http.EnableRedisHttpSession;

/**
 * <p>spring session设置</p>
 * <p>创建日期：2018-01-01</p>
 * 
 * @author 杨洲 yangzhou@neusoft.com
 */
//@Configuration
//@EnableRedisHttpSession(maxInactiveIntervalInSeconds = 600)
public class RedisSessionConfig {

}
